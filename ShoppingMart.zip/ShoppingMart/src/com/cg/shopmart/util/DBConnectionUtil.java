package com.cg.shopmart.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.shopmart.exception.ShopException;

public class DBConnectionUtil {
	public static Connection getConnection() throws ShopException, SQLException{
		Connection conn=null;
		try{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
			conn=ds.getConnection();
		}
		catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}

}
