package com.cg.shopmart.service;

import java.sql.SQLException;
import java.util.List;
import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.dao.IShopDao;
import com.cg.shopmart.dao.ShopDao;
import com.cg.shopmart.exception.ShopException;

public class ShopService implements IShopService {
	IShopDao dao;
	public ShopService(){
		super();
		dao=new ShopDao();
	}

	@Override
	public List<ShopBean> getAllProducts() throws ShopException, SQLException {
		return dao.getAllProducts();
	}
	@Override
	public int addNewCustomer(CustomerBean bean) throws ShopException,
			SQLException {
		// TODO Auto-generated method stub
		return dao.addNewCustomer(bean);
	}

	@Override
	public int updateProduct(int id) throws ShopException, SQLException {
		return dao.updateProduct(id);
		
	}

	@Override
	public List<CustomerBean> getAllPurchases(String custName) throws ShopException,
			SQLException {
		// TODO Auto-generated method stub
		return dao.getAllPurchases(custName);
	}
	

}
