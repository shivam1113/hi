package com.cg.shopmart.bean;

public class ShopBean {
	private int productID;
	private String productName;
	private int pricePerUnit;
	private int noOfUnits;
	public ShopBean() {
		super();
	}
	public ShopBean(int productID, String productName, int pricePerUnit,
			int noOfUnits) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.pricePerUnit = pricePerUnit;
		this.noOfUnits = noOfUnits;
	}
	@Override
	public String toString() {
		return "ShopBean [productID=" + productID + ", productName="
				+ productName + ", pricePerUnit=" + pricePerUnit
				+ ", noOfUnits=" + noOfUnits + "]";
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(int pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public int getNoOfUnits() {
		return noOfUnits;
	}
	public void setNoOfUnits(int noOfUnits) {
		this.noOfUnits = noOfUnits;
	}
}
