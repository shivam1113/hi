package com.cg.shopmart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.exception.ShopException;
import com.cg.shopmart.util.DBConnectionUtil;

public class ShopDao implements IShopDao {

	@Override
	public List<ShopBean> getAllProducts() throws ShopException, SQLException {
		List<ShopBean> productList=new ArrayList<ShopBean>();
		ShopBean shopBean;
		String query="SELECT * FROM shoppingmart";
		try(
			Connection conn=DBConnectionUtil.getConnection();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
		)
		{
			while(rs.next())
			{
				
				int productID=rs.getInt("PRODUCTID");
				String productName=rs.getString("PRODUCTNAME");
				int price=rs.getInt("PRICEPERUNIT");
				int units=rs.getInt("NOOFUNITS");
				shopBean=new ShopBean(productID, productName, price, units);
				productList.add(shopBean);
				
			}
		}
			catch(SQLException e)
			{
				throw new ShopException("sql :"+e.getMessage());
			}
			catch(Exception e){
				throw new ShopException("ERROR :"+e.getMessage());
		}
		return productList;
	}

	@Override
	public int addNewCustomer(CustomerBean bean) throws ShopException, SQLException {
		String qry="INSERT INTO customershistory values (?,?,?,?)";
		
		try(
				Connection conn=DBConnectionUtil.getConnection();
				PreparedStatement statement=conn.prepareStatement(qry);
				//ResultSet rs=statement.executeQuery(query);
			)
			{
				bean.setCustomerID(getCustID());
				statement.setInt(1, bean.getCustomerID());
				statement.setString(2, bean.getCustomerName());
				statement.setLong(3, bean.getCustomerNo());
				statement.setInt(4, bean.getProductID());
				statement.executeQuery();	// for successfull insert
			}
		catch(SQLException e)
		{
			throw new ShopException("SQL ERROR: "+e.getMessage());
		}
		catch(Exception e)
		{
			throw new ShopException("ERROR: "+e.getMessage());
		}
		return bean.getCustomerID();
	}


	private int getCustID() throws ShopException{
		int custID=0;
		String query="SELECT cust_id_seq.NEXTVAL FROM DUAL";
		try(Connection conn=DBConnectionUtil.getConnection();
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
			)
			{
			if(rs.next())
			{
				custID=rs.getInt(1);
			}
			}
		catch(SQLException e)
		{
			throw new ShopException("Unable to generate Transaction ID.");
		}
		
		return custID;
		
	}

		@Override
		public int updateProduct(int id) throws ShopException, SQLException {
			String qry="UPDATE shoppingmart SET noofUnits=(noofUnits-1) where PRODUCTID="+id;
			Connection conn=DBConnectionUtil.getConnection();
			PreparedStatement statement=conn.prepareStatement(qry);
			statement.execute();
			return 1;
		}

		@Override
		public List<CustomerBean> getAllPurchases(String custName) throws ShopException,
				SQLException {
			List<CustomerBean> purchaseList=new ArrayList<CustomerBean>();
			CustomerBean custBean;
			String query="SELECT * FROM customershistory where customername='"+custName+"'";
			try(
				Connection conn=DBConnectionUtil.getConnection();
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
			)
			{
				while(rs.next())
				{
					int customerId=rs.getInt("CUSTOMERID");
					String customerName=rs.getString("CUSTOMERNAME");
					long customerNo=rs.getLong("CUSTOMERNO");
					int productId=rs.getInt("PRODUCTID");
					if(custName.equals(customerName))
					{
					custBean=new CustomerBean(customerId, customerName,customerNo,productId );
					purchaseList.add(custBean);
					}
					else
					{
						purchaseList=null;
					}
				}
			}
				catch(SQLException e)
				{
					throw new ShopException("sql :"+e.getMessage());
				}
				catch(Exception e){
					throw new ShopException("ERROR :"+e.getMessage());
			}
			return purchaseList;
		}

}