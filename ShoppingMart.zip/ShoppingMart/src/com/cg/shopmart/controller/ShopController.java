package com.cg.shopmart.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.exception.ShopException;
import com.cg.shopmart.service.IShopService;
import com.cg.shopmart.service.ShopService;

@WebServlet("*.do")
public class ShopController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   IShopService service;
    public ShopController() {
        super();
        // TODO Auto-generated constructor stub
        service=new ShopService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath().trim();
		HttpSession session=request.getSession(true);
		ShopBean bean=null;
		//String target=null;
		switch(path)
		{
		case "/productList.do":
		{
			try{
				List<ShopBean> productList=service.getAllProducts();
				if(productList.size()>0)
				{
				session.setAttribute("productList", productList);
				request.getRequestDispatcher("home.jsp").forward(request, response);
				}
				else
				{	
					
					request.getRequestDispatcher("error.jsp").forward(request, response);

				}
				break;
				
				}
			catch(ShopException | SQLException e){
				e.printStackTrace();
			}
		break;
		}
		case "/custDetails.do":
		{
			int productID=Integer.parseInt(request.getParameter("productID"));
			//Object productName=session.getAttribute("productName");
			//String productName=request.getParameter("productName");
			String productName =request.getParameter("productName");
			int price=Integer.parseInt(request.getParameter("price"));
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			System.out.println(productID+" "+productName+" "+price);
			session.setAttribute("productName",productName);
			session.setAttribute("productID",productID);
			session.setAttribute("quantity",quantity);
			session.setAttribute("price",price);
			request.getRequestDispatcher("newEntry.jsp").forward(request, response);
		break;
		}
		case "/newEntry.do":
		{
			
			int productID= (int) session.getAttribute("productID");
			int units=Integer.parseInt(request.getParameter("units"));
			int quantity=(int) session.getAttribute("quantity");
			System.out.println(units+" "+quantity);
			String custName=request.getParameter("name");
			long number=Long.parseLong(request.getParameter("number"));
			if(units<=quantity)
			{	CustomerBean custBean=new CustomerBean(productID, custName, number);
			
			try {
				
				int ID=service.addNewCustomer(custBean);
				int xy=service.updateProduct(productID);
/*				*/
				session.setAttribute("ID",ID);
				request.getRequestDispatcher("successEntry.jsp").forward(request, response);
			} catch (ShopException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			}
			else
			{	session.setAttribute("units", units);
				request.getRequestDispatcher("errorQuantity.jsp").forward(request, response);
			}
		break;
		}
		
		case "/viewCustDetails.do":
		{
			try{
				String custName=request.getParameter("cust");
				System.out.println(custName);
				List<CustomerBean> custList=service.getAllPurchases(custName);
				if(custList.size()>0)
				{
				CustomerBean cust=custList.get(0);
				session.setAttribute("custName", cust.getCustomerName());
				session.setAttribute("custList", custList);
				request.getRequestDispatcher("PurchaseHistory.jsp").forward(request, response);
				}
				else
				{	session.setAttribute("custName", custName);
					request.getRequestDispatcher("error.jsp").forward(request, response);

				}
				break;
				
				}
			catch(ShopException | SQLException e){
				e.printStackTrace();
			}
		break;
		}
		
		}
		
}

}
